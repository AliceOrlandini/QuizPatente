package quizpatente;

import java.io.*;
import java.net.*;
import java.util.*;
import gestore_xml.*;

public class InvioAzioneAServerLog { // (1)
    
    public QuizPatenteGUI interfacciaGrafica;
    public String nomeApplicazione;
    public GestoreXML gestoreXML;
    
    InvioAzioneAServerLog(QuizPatenteGUI interfacciaGrafica, String nomeApplicazione) {
        
        this.interfacciaGrafica = interfacciaGrafica;
        this.nomeApplicazione   = nomeApplicazione;
        this.gestoreXML         = new GestoreXML();
    }
    
    public void inviaAzioneAServerLog(String azione) {
        
        try(Socket s = new Socket(interfacciaGrafica.parametriConfigurazione.indirizzoIPServerLog, interfacciaGrafica.parametriConfigurazione.portaServerLog);
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());) {
            
            AzioneUtente messaggioDaInviare = new AzioneUtente(nomeApplicazione, interfacciaGrafica.parametriConfigurazione.indirizzoIPClient, new Date(), azione);
            dout.writeUTF(gestoreXML.convertiInStringa(messaggioDaInviare));
        
        } catch(IOException ex) {
            ex.printStackTrace();
        }
    }
}
/*
Note:
(1):  Questa classe si occupa di creare il messaggio di log e di inviarlo 
      tramite socket al server. 
*/