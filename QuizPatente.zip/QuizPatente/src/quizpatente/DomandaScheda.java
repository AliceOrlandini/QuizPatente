package quizpatente;

public class DomandaScheda { // (1)
    
    public String domanda;
    public Boolean risposta;
    public String immagineUrl;
    
    DomandaScheda(String domanda, Boolean risposta, String immagineUrl) {
        
        this.domanda = domanda;
        this.risposta = risposta;
        this.immagineUrl = immagineUrl;
    }
}
/*
Note:
(1): Questa classe rappresenta il concetto di domanda della scheda d'esame con 
     la stringa della domanda, la risposta e l'url dell'immagine qualora sia
     presente. 
*/