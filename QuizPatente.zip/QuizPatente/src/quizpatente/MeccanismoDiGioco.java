package quizpatente;

import java.util.*;
import javafx.application.*;
import javafx.event.*;
import javafx.scene.chart.*;
import javafx.scene.image.*;
import gestore_xml.*;

public class MeccanismoDiGioco { // (1)
    
    public QuizPatenteGUI interfacciaGrafica;
    public EsecutoreRichiestaUtente richiestaUtente;
    public Timer timer;
    public int durataQuiz;
    public List<DomandaScheda> listaDomandeScheda;
    public int indiceDomandaMostrata;
    public int numeroRisposteSbagliate;
    public Boolean quizInterrotto;

    MeccanismoDiGioco(QuizPatenteGUI interfacciaGrafica) {
        
        this.richiestaUtente            = new EsecutoreRichiestaUtente(interfacciaGrafica);
        this.interfacciaGrafica         = interfacciaGrafica;
        this.durataQuiz                 = -1; // (2)
        this.indiceDomandaMostrata      = 0;
        this.numeroRisposteSbagliate    = 0;
        this.timer                      = new Timer(); 
        this.quizInterrotto             = false;
        
        this.interfacciaGrafica.bottoneVero.setOnAction((ActionEvent ev) -> { // (3)
            controlloRisposta(true);
        });
        this.interfacciaGrafica.bottoneFalso.setOnAction((ActionEvent ev) -> {
            controlloRisposta(false);
        });
    }
    
    public void iniziaGioco() { 

        inizializzaVariabili();
        scaricaScheda(); // (4)
        mostraBoxDomande();
        mostraNuovaDomanda();
        impostaTimer();
        
        interfacciaGrafica.azioneUtente.inviaAzioneAServerLog("INIZIO SCHEDA");
    }
    
    public void riprendiGioco(int durataQuiz, int numeroRisposteSbagliate, int indiceDomandaMostrata, List<DomandaScheda> listaDomandeScheda) {
        
        this.durataQuiz                 = durataQuiz;
        this.numeroRisposteSbagliate    = numeroRisposteSbagliate;
        this.indiceDomandaMostrata      = indiceDomandaMostrata;
        this.listaDomandeScheda         = listaDomandeScheda;
        this.quizInterrotto             = true;
        
        mostraBoxDomande();
        mostraNuovaDomanda();
        impostaTimer();
    }
    
    public void inizializzaVariabili() {
        
        durataQuiz              = 1800; // (5)
        indiceDomandaMostrata   = 0;
        numeroRisposteSbagliate = 0;
    }
    
    public void controlloRisposta(Boolean rispostaInviata) {
        
        if(!rispostaInviata.equals(listaDomandeScheda.get(indiceDomandaMostrata).risposta))
            numeroRisposteSbagliate++;
        indiceDomandaMostrata++;
        
        if(indiceDomandaMostrata == 40 || durataQuiz <= 0) // (6)
            finisciGioco();
        else
            mostraNuovaDomanda();
    }
    
    public void finisciGioco() {
        
        timer.cancel(); // (7)
        stampaRisultati();
        
        int minuti  = durataQuiz/60;
        minuti      = 30 - minuti;
        
        durataQuiz = -1; // (8)
        
        if(quizInterrotto) { // (9)
            interfacciaGrafica.messaggioErrore.setVisible(false);
            interfacciaGrafica.messaggioErrore.setStyle("-fx-text-fill: red;");
        }
    
        Boolean operazioneEseguita = richiestaUtente.inviaRisultatiQuiz(numeroRisposteSbagliate, minuti); // (10)
        if(!operazioneEseguita) {
            interfacciaGrafica.messaggioErrore.setText("Impossibile aggiornare il database");
            interfacciaGrafica.messaggioErrore.setVisible(true);
            
        }
        
        aggiornaInterfacciaGrafica(minuti);
        
        interfacciaGrafica.azioneUtente.inviaAzioneAServerLog("FINE SCHEDA");
    }
    
    public void aggiornaInterfacciaGrafica(int minuti) { // (11)
        
        String esito;
        if(numeroRisposteSbagliate > 4)
            esito = "Bocciato";
        else
            esito = "Promosso";
        
        interfacciaGrafica.listaSchede.get(interfacciaGrafica.numeroSchedaCliccata).setErrori(String.valueOf(numeroRisposteSbagliate));
        interfacciaGrafica.listaSchede.get(interfacciaGrafica.numeroSchedaCliccata).setMinuti(String.valueOf(minuti));
        interfacciaGrafica.listaSchede.get(interfacciaGrafica.numeroSchedaCliccata).setEsito(esito);
        interfacciaGrafica.listaSchede.get(interfacciaGrafica.numeroSchedaCliccata).setCompletata("SI");
        
        interfacciaGrafica.tabellaSchede.getColumns().get(interfacciaGrafica.numeroSchedaCliccata).setVisible(false); // (12)
        interfacciaGrafica.tabellaSchede.getColumns().get(interfacciaGrafica.numeroSchedaCliccata).setVisible(true);
        
        int numeroIterazioni = interfacciaGrafica.listaSchede.size(); // (13)
        if(numeroIterazioni > interfacciaGrafica.parametriConfigurazione.numeroRigheTabella)
            numeroIterazioni = interfacciaGrafica.parametriConfigurazione.numeroRigheTabella;
        for(int j = 0; j < numeroIterazioni; j++) {
            if(interfacciaGrafica.listaSchede.get(j).getMinuti() == null)
                interfacciaGrafica.checkBoxSchedaCompletata[j].setDisable(false);
        }
        
        Integer index = interfacciaGrafica.lineaGrafico.getData().size() + 1;
        XYChart.Data nuovoPunto = new XYChart.Data<Integer, Integer>(index, numeroRisposteSbagliate);
        interfacciaGrafica.lineaGrafico.getData().add(nuovoPunto);
    }
    
    public void stampaRisultati() { // (14)
        
        interfacciaGrafica.labelTempoRimanente.setText("Risultati: ");
        String esito;
        if(durataQuiz <= 0)
            esito = "Tempo scaduto.";
        else if(numeroRisposteSbagliate > 4){
            esito = "Bocciato...";
            interfacciaGrafica.immagineDomanda.setImage(new Image("file:../../myfiles/ImmaginiRisultati/Bocciato.png"));
        }
        else {
            esito = "Promosso!";
            interfacciaGrafica.immagineDomanda.setImage(new Image("file:../../myfiles/ImmaginiRisultati/Promosso.png"));
        }
        
        int minuti = durataQuiz/60;
        minuti = 30 - minuti;
        
        interfacciaGrafica.labelDomanda.setText(esito + " Hai commesso " + numeroRisposteSbagliate + " errori\n" + "ed hai impiegato " + minuti + " minuti.");
        interfacciaGrafica.bottoneVero.setVisible(false);
        interfacciaGrafica.bottoneFalso.setVisible(false);
        interfacciaGrafica.barraProgressoDomande.setProgress(1);
    }
    
    public void mostraNuovaDomanda() {
        
        interfacciaGrafica.labelDomanda.setText(listaDomandeScheda.get(indiceDomandaMostrata).domanda);
        interfacciaGrafica.immagineDomanda.setImage(new Image("file:../../myfiles/ImmaginiDomande/" + listaDomandeScheda.get(indiceDomandaMostrata).immagineUrl + ".png"));
        interfacciaGrafica.barraProgressoDomande.setProgress(0.025*indiceDomandaMostrata);
    }
    
    public void scaricaScheda() {

        listaDomandeScheda = richiestaUtente.ottieniDomandeScheda();
        Collections.shuffle(listaDomandeScheda);
    }
    
    public void mostraBoxDomande() {
        
        interfacciaGrafica.labelTempoRimanente.setVisible(true);
        interfacciaGrafica.labelDomanda.setVisible(true);
        interfacciaGrafica.immagineDomanda.setVisible(true);
        interfacciaGrafica.bottoneVero.setVisible(true);
        interfacciaGrafica.bottoneFalso.setVisible(true);
        interfacciaGrafica.barraProgressoDomande.setVisible(true);
    }
    
    public void impostaTimer() { // (15)
        
        timer.cancel();
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                if(durataQuiz > 0) {
                    stampaLabelTempoTrascorso(durataQuiz);
                    durataQuiz--;
                }
                else {
                    timer.cancel();
                }
            }
        }, 1000,1000); 
    }

    public void stampaLabelTempoTrascorso(int durata) {
        int minuti = durata/60;
        int secondi = durata%60;
        
        if(secondi < 10) // (16)
            Platform.runLater(() -> interfacciaGrafica.labelTempoRimanente.setText("Tempo Rimanente: " + minuti + ":0" + secondi));
        else 
            Platform.runLater(() -> interfacciaGrafica.labelTempoRimanente.setText("Tempo Rimanente: " + minuti + ":" + secondi));
    }
}
/*
Note:
(1):  Questa classe si occupa di gestire tutto il quiz. 
(2):  All'inizio durataQuiz viene impostato negativo perchè in questo modo la 
      cache riconosce che il quiz non è stato avviato. 
(3):  Entrambi i bottoni chiamano la stessa funzione ma gli viene passato true o 
      false a seconda del bottone premuto.
(4):  Vengono scaricate dal database le domande della scheda ed il vettore in 
      cui sono salvate viene mescolato per evitare di trovarle in ordine. 
(5):  1800 secondi corrispondono a 30 minuti.
(6):  Il quiz finisce o quando l'utente ha risposto a tutte le 40 domande oppure
      quando finisce il tempo. Se il quiz non è finito viene mostrata una nuova
      domanda. 
(7):  Quando il quiz termina viene cancellato il timer e vengono mostrati
      all'utente i suoi risultati come il tempo impiegato e il numero di errori
      commessi. 
(8):  Si imposta durataQuiz negativo per segnalare che l'utente ha concluso il 
      quiz. 
(9):  Si toglie il messaggio che comunicava che la scheda era stata ricaricata
      dalla cache. 
(10): Si inviano i risultati al database e si mostra un messaggio di errore nel 
      caso in cui l'invio dei risultati non fosse andato a buon fine. 
(11): Il metodo AggiornaInterfacciaGrafica si occupa di aggiornare il grafico 
      e la tabella presenti nell'interfaccia. 
(12): Queste due righe servono per refreshare la riga della tabella per far 
      comparire a schermo l'aggiornamento. 
(13): Questo for serve per rendere cliccabili nell'interfaccia grafica 
      le checkbox relative alle schede non ancora completate.
(14): Il metodo stampaRisultati si comporta in modo differente a seconda che 
      l'utente sia promosso o bocciato oppure se il quiz si è concluso a causa
      del tempo. 
(15): Il metodo impostaTimer decrementa durataQuiz ogni secondo finchè non 
      diventa uguale a zero. 
(16): Questo if è necessario solo per una questione di formattazione. 
*/