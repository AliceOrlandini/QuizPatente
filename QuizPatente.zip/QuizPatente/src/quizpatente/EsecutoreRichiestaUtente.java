package quizpatente;

import java.util.*;
import javafx.scene.chart.*;
import gestore_xml.*;

public class EsecutoreRichiestaUtente { // (1)
    
    public QuizPatenteGUI interfacciaGrafica;
    public InterlocutoreDB interlocutoreDB;
    
    public EsecutoreRichiestaUtente(QuizPatenteGUI interfacciaGrafica) {
        
        this.interfacciaGrafica = interfacciaGrafica;

        interlocutoreDB = new InterlocutoreDB(interfacciaGrafica.parametriConfigurazione.indirizzoIPDatabase, interfacciaGrafica.parametriConfigurazione.portaDatabase, interfacciaGrafica.parametriConfigurazione.usernameDatabase, interfacciaGrafica.parametriConfigurazione.passwordDatabase, interfacciaGrafica.parametriConfigurazione.numeroRigheTabella, interfacciaGrafica.checkBoxSchedaCompletata);
    }
    
    public List<Scheda> elencaSchede() { 
        
        String richiesta = "SELECT S.CodiceScheda, S.Difficolta, IF(SV.DataSvolgimento IS NOT NULL, 'SI', 'NO') AS Completata, CASE WHEN SV.DataSvolgimento IS NULL THEN NULL WHEN SV.DataSvolgimento IS NOT NULL AND SV.Errori > 4 THEN 'Bocciato' WHEN SV.DataSvolgimento IS NOT NULL AND SV.Errori <= 4 THEN 'Promosso' END AS Esito, SV.Errori, SV.Minuti FROM (Scheda S CROSS JOIN Utente U) LEFT OUTER JOIN Svolge SV ON (SV.Utente = U.NomeUtente AND S.CodiceScheda = SV.Scheda) WHERE U.NomeUtente = '" + interfacciaGrafica.campoNomeUtente.getText() + "' ORDER BY S.CodiceScheda;";
        List<Scheda> listaSchede = interlocutoreDB.eseguiRichiestaDatiTabella(richiesta);

        return listaSchede;
    }
    
    public List<XYChart.Data> ottieniDatiGrafico() {
        
        String richiesta = "SELECT SV.Errori FROM Svolge SV WHERE SV.Utente = '"+ interfacciaGrafica.campoNomeUtente.getText() + "' ORDER BY SV.DataSvolgimento;";
        List<XYChart.Data> listaDatiGrafico = interlocutoreDB.eseguiRichiestaDatiGrafico(richiesta);
        
        return listaDatiGrafico;
    }
    
    public List<DomandaScheda> ottieniDomandeScheda() {
    
        String numeroScheda = String.valueOf(interfacciaGrafica.numeroSchedaCliccata);
        String richiesta = "SELECT D.Testo, D.Risposta, D.ImmagineUrl FROM Domanda D WHERE D.Scheda = " + numeroScheda + ";";
        List<DomandaScheda> listaDomandeScheda = interlocutoreDB.eseguiRichiestaDomandeScheda(richiesta);
        
        return listaDomandeScheda;
    }
    
    public Boolean inviaRisultatiQuiz(int numeroRisposteSbagliate, int minuti) {
        
        Boolean operazioneEseguita;
        String richiesta = "INSERT INTO Svolge VALUES('" + interfacciaGrafica.campoNomeUtente.getText() + "'," + interfacciaGrafica.numeroSchedaCliccata + "," + String.valueOf(minuti) + "," + String.valueOf(numeroRisposteSbagliate) + ",CURRENT_TIMESTAMP);";
        operazioneEseguita = interlocutoreDB.eseguiRichiestaInviaRisultatiQuiz(richiesta);
        return operazioneEseguita;
    }
}
/*
Note:
(1):  Questa classe si occupa della gestione del middleware ovvero fa da
      intermediario tra interfaccia grafica e comunicazione effettiva col 
      database. Infatti, prepara la query e la trasmette all'interlocutore DB.
*/