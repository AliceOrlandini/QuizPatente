package quizpatente;

import javafx.beans.property.*;
import javafx.scene.control.*;

public class Scheda { // (1)
    
    private final SimpleStringProperty scheda;
    private final SimpleStringProperty difficolta;
    private final SimpleStringProperty completata;
    private final SimpleStringProperty esito;
    private final SimpleStringProperty errori;
    private final SimpleStringProperty minuti;
    private final CheckBox boxCompletata;
    
    public Scheda(String scheda, String difficolta, String completata, String esito, String errori, String minuti, CheckBox boxCompletata) {
        
        this.scheda     = new SimpleStringProperty(scheda);
        this.difficolta = new SimpleStringProperty(difficolta);
        this.completata = new SimpleStringProperty(completata);
        this.esito      = new SimpleStringProperty(esito);
        this.errori     = new SimpleStringProperty(errori);
        this.minuti     = new SimpleStringProperty(minuti);
        this.boxCompletata = boxCompletata;
    }
    
    public String getCodiceScheda() { return "Scheda " + scheda.get(); }
    
    public String getDifficolta() { return difficolta.get(); }
    
    public CheckBox getCompletata() { 
        
        if(completata.get().equals("SI")) { // (2)
            boxCompletata.setSelected(true);
            boxCompletata.setDisable(true);
            boxCompletata.setStyle("-fx-opacity: 1;");
        }
        else {
            boxCompletata.setSelected(false);
        }
            
        return boxCompletata; 
    }
    
    public String getEsito() { return esito.get(); }
    
    public String getErrori() { return errori.get(); }
    
    public String getMinuti() { return minuti.get(); }
    
    public void setCompletata(String completata) { 
        
        this.completata.set(completata);
        
        if(completata.equals("SI")) {
            this.boxCompletata.setSelected(true);
            this.boxCompletata.setDisable(true);
            boxCompletata.setStyle("-fx-opacity: 1;");
        } else {
            boxCompletata.setSelected(false);
        }
    }
    
    public void setEsito(String esito) { this.esito.set(esito); }
    
    public void setErrori(String errori) { this.errori.set(errori); }
    
    public void setMinuti(String minuti) { this.minuti.set(minuti); }
}
/*
Note:
(1):  Questa classe rappresenta il concetto di scheda d'esame con l'id, la 
      difficoltà e, se l'utente ha completato la scheda, anche l'esito, gli 
      errori commessi ed i minuti impiegati. 
(2):  Se la scheda è stata completata dall'utente allora si disabilita la 
      checkbox e si imposta completata. 
*/