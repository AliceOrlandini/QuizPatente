package quizpatente;

import javafx.application.*;
import javafx.collections.*;
import javafx.event.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import gestore_xml.*;

public class QuizPatenteGUI extends Application {

    public TextField campoNomeUtente; 
    public Button bottoneCaricaUtente;
    public Label messaggioErrore;
    public TableView<Scheda> tabellaSchede;
    public ObservableList<Scheda> listaSchede;
    public CheckBox[] checkBoxSchedaCompletata; 
    public int numeroSchedaCliccata; // (1)
    public LineChart<Number, Number> grafico;
    public XYChart.Series lineaGrafico;
    public Region boxQuiz;
    public Label labelTempoRimanente;
    public Label labelDomanda;
    public ImageView immagineDomanda;
    public Button bottoneVero;
    public Button bottoneFalso;
    public ProgressBar barraProgressoDomande;
    public EsecutoreRichiestaUtente richiestaUtente; 
    public MeccanismoDiGioco meccanismoGioco; 
    public ParametriConfigurazione parametriConfigurazione; 
    public InvioAzioneAServerLog azioneUtente; 
    public String nomeApplicazione;
    public CacheDati cacheDati; 
    
    public void start(Stage stage) {
        
        nomeApplicazione        = "QuizPatente";
        parametriConfigurazione = new ParametriConfigurazione(); // (2)
        azioneUtente            = new InvioAzioneAServerLog(this, nomeApplicazione);
        
        inizializzaInterfaccia(); // (3)
        richiestaUtente  = new EsecutoreRichiestaUtente(this);
        meccanismoGioco  = new MeccanismoDiGioco(this);
        cacheDati        = new CacheDati(this); 
        
        Group elementiInterfaccia = new Group(campoNomeUtente, bottoneCaricaUtente, messaggioErrore, tabellaSchede, grafico, boxQuiz, labelTempoRimanente, labelDomanda, immagineDomanda, bottoneVero, bottoneFalso, barraProgressoDomande);
        Scene scene = new Scene(elementiInterfaccia, 1070, 900);
        scene.getStylesheets().add("FoglioDiStile.css"); // (4)
        
        stage.setOnCloseRequest((WindowEvent we) -> {
            meccanismoGioco.timer.cancel(); // (5)
            cacheDati.salvaDatiInCache();
            azioneUtente.inviaAzioneAServerLog("TERMINE");
        });
        
        stage.setTitle("Quiz della Patente");
        stage.getIcons().add(new Image("file:../../myfiles/immaginiDomande/domanda2.png"));
        stage.setScene(scene);
        stage.show();
        azioneUtente.inviaAzioneAServerLog("AVVIO");
    }
    
    public void inizializzaInterfaccia() { 
        
        inizializzaCampoIngressoUtente();
        inizializzaTabella();
        inizializzaGrafico();
        inizializzaBoxDomande(); 
    }
    
    public void inizializzaCampoIngressoUtente() {
        
        campoNomeUtente = new TextField();
        campoNomeUtente.setPromptText("Nome Utente");
        campoNomeUtente.setFont(Font.font(parametriConfigurazione.fontCaratteri, FontWeight.BOLD, 15));
        campoNomeUtente.setStyle("-fx-border-width: 0 0 0 0; -fx-background-color: #EEEDED; -fx-alignment: center");
        campoNomeUtente.setMinSize(150, 30);
        campoNomeUtente.setMaxSize(150, 30);
        posizioneElemento(campoNomeUtente, 30, 30);
        
        bottoneCaricaUtente = new Button("Invio");
        bottoneCaricaUtente.setMinSize(100, 30);
        bottoneCaricaUtente.setFont(Font.font(parametriConfigurazione.fontCaratteri, FontWeight.BOLD, 15));
        bottoneCaricaUtente.setStyle("-fx-text-fill: white; -fx-border-width: 0 0 0 0; -fx-background-color: #3A9FE1; -fx-alignment: center");
        bottoneCaricaUtente.setOnAction((ActionEvent ev) -> {
            caricaUtente();
        });
        posizioneElemento(bottoneCaricaUtente, 200, 30);
        
        messaggioErrore = new Label("Messaggio Errore");
        messaggioErrore.setVisible(false);
        messaggioErrore.setFont(Font.font(parametriConfigurazione.fontCaratteri, FontWeight.BOLD, 15));
        messaggioErrore.setStyle("-fx-text-fill: red;");
        posizioneElemento(messaggioErrore, 30, 75);
    }
    
    public void inizializzaTabella() {  
        
        listaSchede = FXCollections.observableArrayList();
        tabellaSchede = new TableView<>();
        posizioneElemento(tabellaSchede, 30, 100);
        tabellaSchede.setMinSize(480, 180);
        tabellaSchede.setMaxSize(580, 280);
        if(!parametriConfigurazione.fontCaratteri.equals("Arial")) // CHECK!!
            tabellaSchede.setStyle("-fx-font-family: '" + parametriConfigurazione.fontCaratteri + "';");
        
        TableColumn colonnaSchede       = new TableColumn("Scheda");
        TableColumn colonnaDifficolta   = new TableColumn("Difficoltà");
        TableColumn colonnaCompletata   = new TableColumn("Completata");
        TableColumn colonnaEsito        = new TableColumn("Esito");
        TableColumn colonnaErrori       = new TableColumn("Errori");
        TableColumn colonnaMinuti       = new TableColumn("Minuti");
        
        colonnaSchede.setStyle("-fx-font-weight:bold;");
        colonnaSchede.setSortable(false);
        colonnaDifficolta.setSortable(false);
        colonnaCompletata.setSortable(false);
        colonnaEsito.setSortable(false);
        colonnaErrori.setSortable(false);
        colonnaMinuti.setSortable(false);
        
        colonnaSchede.setCellValueFactory(new PropertyValueFactory("CodiceScheda"));
        colonnaDifficolta.setCellValueFactory(new PropertyValueFactory("Difficolta"));
        colonnaCompletata.setCellValueFactory(new PropertyValueFactory("Completata"));
        colonnaEsito.setCellValueFactory(new PropertyValueFactory("Esito"));
        colonnaErrori.setCellValueFactory(new PropertyValueFactory("Errori"));
        colonnaMinuti.setCellValueFactory(new PropertyValueFactory("Minuti"));
        
        inizializzaCheckBox(); // (6)
        
        tabellaSchede.setItems(listaSchede);
        tabellaSchede.getColumns().addAll(colonnaSchede, colonnaDifficolta,
                colonnaCompletata, colonnaEsito, colonnaErrori, colonnaMinuti);
    }
    
    public void inizializzaCheckBox() { 
        
        checkBoxSchedaCompletata = new CheckBox[parametriConfigurazione.numeroRigheTabella];
        for(int i = 0; i < parametriConfigurazione.numeroRigheTabella; i++){
            checkBoxSchedaCompletata[i] = new CheckBox();
            checkBoxSchedaCompletata[i].setId(String.valueOf(i)); // (7)
            checkBoxSchedaCompletata[i].setOnAction(new EventHandler<ActionEvent>(){ // (8)
                public void handle(ActionEvent event) {
                    
                    for(int j = 0; j < parametriConfigurazione.numeroRigheTabella; j++) { 
                        checkBoxSchedaCompletata[j].setDisable(true);
                    }
                    Object source = event.getSource();
                    if (source instanceof CheckBox) { 
                        CheckBox clickedBtn = (CheckBox) source; 
                        numeroSchedaCliccata = Integer.parseInt(clickedBtn.getId());
                    }
                    meccanismoGioco.iniziaGioco();
                }
            });
        }
    }
    
    public void inizializzaGrafico() {
        
        NumberAxis asseX = new NumberAxis(1,10,1);
        asseX.setLabel("Tempo");
        
        NumberAxis asseY = new NumberAxis(0,40,5);
        asseY.setLabel("Risposte Sbagliate");
        
        grafico = new LineChart<>(asseX,asseY);
        grafico.setLegendVisible(false);
        grafico.setCreateSymbols(false);
        posizioneElemento(grafico, 550, 90);
        grafico.setMinSize(370, 250);
        grafico.setMaxSize(470, 350);
        grafico.setStyle("-fx-font-family: '" + parametriConfigurazione.fontCaratteri + "';");
        
        lineaGrafico = new XYChart.Series();
        
        grafico.getData().add(lineaGrafico);
    }
    
    public void inizializzaBoxDomande() {
        
        boxQuiz = new Region();
        if(parametriConfigurazione.coloreSfondoBoxDomande.equals("#FFFFFF"))
            boxQuiz.setStyle("-fx-border-style: solid; -fx-border-width:2; -fx-border-radius: 20;");
        else
            boxQuiz.setStyle("-fx-background-color: " + parametriConfigurazione.coloreSfondoBoxDomande + "; -fx-border-style: solid; -fx-border-width:2;");
        posizioneElemento(boxQuiz, 100, 480);
        boxQuiz.setMinSize(850, 350);
        
        labelTempoRimanente = new Label("Tempo Rimanente: ");
        posizioneElemento(labelTempoRimanente, 130, 500);
        labelTempoRimanente.setFont(Font.font(parametriConfigurazione.fontCaratteri, FontWeight.BOLD, 20));
        labelTempoRimanente.setVisible(false);
        
        labelDomanda = new Label("");
        posizioneElemento(labelDomanda, 130, 550);
        labelDomanda.setFont(Font.font(parametriConfigurazione.fontCaratteri, 26));
        labelDomanda.setMaxSize(500, 500);
        labelDomanda.setWrapText(true);
        labelDomanda.setVisible(false);
        
        immagineDomanda = new ImageView("file:../../myfiles/immagine.png");
        posizioneElemento(immagineDomanda, 680, 520);
        immagineDomanda.setFitHeight(200);
        immagineDomanda.setFitWidth(200);
        immagineDomanda.setVisible(false);
        
        inizializzaBottoniRisposta();
    }
    
    public void inizializzaBottoniRisposta() {
        
        ImageView immagineVero = new ImageView(new Image("file:../../myfiles/BottoniRisposte/BottoneTrue.png"));
        immagineVero.setFitHeight(70);
        immagineVero.setPreserveRatio(true);
        bottoneVero = new Button();
        posizioneElemento(bottoneVero, 430, 720);
        bottoneVero.setMinSize(80, 50);
        bottoneVero.setGraphic(immagineVero);
        bottoneVero.setVisible(false);
        
        ImageView immagineFalso = new ImageView(new Image("file:../../myfiles/BottoniRisposte/BottoneFalse.png"));
        immagineFalso.setFitHeight(70);
        immagineFalso.setPreserveRatio(true);
        bottoneFalso = new Button();
        posizioneElemento(bottoneFalso, 530, 720);
        bottoneFalso.setMinSize(80, 50);
        bottoneFalso.setGraphic(immagineFalso);
        bottoneFalso.setVisible(false);
        
        barraProgressoDomande = new ProgressBar(0);
        posizioneElemento(barraProgressoDomande, 100, 850);
        barraProgressoDomande.setPrefSize(845, 20);
        barraProgressoDomande.setProgress(0);
        barraProgressoDomande.setVisible(false);
    }
    
    public void aggiornaGrafico() { // (9)
        
        lineaGrafico.getData().clear();
        lineaGrafico.getData().addAll(richiestaUtente.ottieniDatiGrafico()); 
    }
    
    public void ottieniElencoSchede() { // (10)
        
        listaSchede.clear();
        listaSchede = FXCollections.observableArrayList(richiestaUtente.elencaSchede());

        tabellaSchede.setItems(listaSchede);
    }
    
    public void caricaUtente() { // (11)
        
        if(campoNomeUtente.getText().trim().isEmpty()) {
            messaggioErrore.setText("Inserire il nome utente");
            messaggioErrore.setVisible(true);
            return;
        }
        
        messaggioErrore.setVisible(false);
        ottieniElencoSchede();
        aggiornaGrafico();
        azioneUtente.inviaAzioneAServerLog("LOGIN");
    }
    
    public void posizioneElemento(Node elemento, int X, int Y) { // (12)
        elemento.setLayoutX(X);
        elemento.setLayoutY(Y);
    }
}

/*
(1):  NumeroSchedaCliccata è utile per la classe MeccanismoDiGioco sia per 
      scaricare le domande relative a quella scheda, sia per inviare i risultati 
      una volta concluso il quiz. 
(2):  Vengono inizializzati i parametri di configurazione.
(3):  Vengono inizializzati tutti gli elementi appartenenti all'interfaccia
      grafica; in particolare, questo metodo si limita a chiamare dei metodi 
      specifici che agiscono su ogni sezione dell'interfaccia.
(4):  Lo stile dell'interfaccia è definito nel file FoglioDiStile.css.
(5):  Quando l'applicazione viene chiusa viene eliminato il timer definito in 
      MeccanismoDiGioco. Senza questa chiamata l'applicazione rimarrebbe attiva 
      in background e sarebbe necessario stoppare l'esecuzione da terminale.
(6):  Le check box presenti nella tabella vengono inizializzate con un metodo 
      a parte.
(7):  Viene assegnato ad ogni checkbox un id corrispondente al numero della 
      riga a cui appartiene, in questo modo quando essa verrà cliccata sarà 
      aggiornato l'intero NumeroSchedaCliccata. 
(8):  Quando la checkbox viene cliccata vengono disabilitate tutte le checkbox
      in modo da non rischiare che l'utente inizi un'altra scheda prima che ha
      finito quella appena cliccata. Poi, viene ricavato l'id della checkbox
      per assegnarlo a NumeroSchedaCliccata ed infine viene chiamato il metodo 
      di MeccanismoDiGioco per iniziare il quiz.
(9):  Questo metodo cancella il contenuto del grafico ed invia una nuova 
      richiesta al database per ottenere i dati da inserire nel grafico.
(10): Questo metodo cancella il contenuto della listaSchede ed invia una nuova 
      richiesta al database per ottenere i dati da inserire nella tabella.
(11): Quando il bottone "invia" viene cliccato prima si controlla che 
      effettivamente l'utente abbia inserito un nome utente nell'apposito campo
      e poi si fa una richiesta al database per ottenere le schede e i dati da
      inserire nel grafico.
(12): Questo metodo serve per compattare le chiamate per posizionare l'elemento
      correttamente. 
*/