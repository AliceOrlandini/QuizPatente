package quizpatente;

import java.sql.*;
import java.util.*;
import javafx.scene.chart.*;
import javafx.scene.control.*;

public class InterlocutoreDB { // (1)
    
    String indirizzoIP;
    int portaDB;
    String usernameDB;
    String passwordDB;
    int numeroRigheTabella;
    CheckBox[] checkBoxCompletata;
    
    public InterlocutoreDB(String indirizzoIP, int portaDB, String usernameDB, String passwordDB, int numeroRigheTabella, CheckBox[] checkBoxCompletata) {
        
        this.indirizzoIP        = indirizzoIP;
        this.portaDB            = portaDB;
        this.usernameDB         = usernameDB;
        this.passwordDB         = passwordDB;
        this.numeroRigheTabella = numeroRigheTabella;
        this.checkBoxCompletata = checkBoxCompletata;
    }
    
    public List<Scheda> eseguiRichiestaDatiTabella(String richiesta) {
        
        List<Scheda> listaSchede = new ArrayList<>();
        String connessioneDB = "jdbc:mysql://" + indirizzoIP + ":" + portaDB + "/quiz_patente";
        
        try (
                Connection connection   = DriverManager.getConnection(connessioneDB, usernameDB, passwordDB);
                Statement statement     = connection.createStatement();
        ) {
                ResultSet resultSet = statement.executeQuery(richiesta);
                int index = 0;
                while(resultSet.next() && numeroRigheTabella > 0) {
                    listaSchede.add(new Scheda(resultSet.getString("CodiceScheda"), resultSet.getString("Difficolta"), 
                                                resultSet.getString("Completata"), resultSet.getString("Esito"), 
                                                resultSet.getString("Errori"), resultSet.getString("Minuti"),
                                                checkBoxCompletata[index]));
                    
                    index++;
                    numeroRigheTabella--;
                }
                
        } catch (SQLException ex){System.err.println(ex.getMessage());}
        
        return listaSchede;
    }
    
    public List<XYChart.Data> eseguiRichiestaDatiGrafico(String richiesta) {
        List<XYChart.Data> listaDatiGrafico = new ArrayList<>();
        String connessioneDB = "jdbc:mysql://" + indirizzoIP + ":" + portaDB + "/quiz_patente";
        
        try (
            Connection connection   = DriverManager.getConnection(connessioneDB, usernameDB, passwordDB);
            Statement statement     = connection.createStatement();
        ) {
            ResultSet resultSet = statement.executeQuery(richiesta);
            Integer index = 1;
            while(resultSet.next()) {
                XYChart.Data sample = new XYChart.Data<Integer, Integer>(index, resultSet.getInt("Errori"));
                index++;
                listaDatiGrafico.add(sample);
            }   
        } catch (SQLException ex){System.err.println(ex.getMessage());}
        
        return listaDatiGrafico; 
    }
    
    public List<DomandaScheda> eseguiRichiestaDomandeScheda(String richiesta) {
        List<DomandaScheda> listaDomandeScheda = new ArrayList<>();
        String connessioneDB = "jdbc:mysql://" + indirizzoIP + ":" + portaDB + "/quiz_patente";
        
        try (
            Connection connection   = DriverManager.getConnection(connessioneDB, usernameDB, passwordDB);
            Statement statement     = connection.createStatement();
        ) {
            ResultSet resultSet = statement.executeQuery(richiesta);
            while(resultSet.next()) {
                listaDomandeScheda.add(new DomandaScheda(resultSet.getString("Testo"),resultSet.getBoolean("Risposta"),resultSet.getString("ImmagineUrl")));
            }     
        } catch (SQLException ex){System.err.println(ex.getMessage());}
        
        return listaDomandeScheda;  
    }
    
    public Boolean eseguiRichiestaInviaRisultatiQuiz(String richiesta) {
        
        Boolean operazioneEseguita = false;
        String connessioneDB = "jdbc:mysql://" + indirizzoIP + ":" + portaDB + "/quiz_patente";
        
        try (
            Connection connection   = DriverManager.getConnection(connessioneDB, usernameDB, passwordDB);
            Statement statement     = connection.createStatement();
        ) {
            operazioneEseguita = statement.executeUpdate(richiesta) != 0;     
        } catch (SQLException ex){System.err.println(ex.getMessage());}
        
        return operazioneEseguita;
    }
}
/*
Note:
(1):  Questa classe si occupa di stabilire una connessione con il database, di
      trasmettere la query ricevuta dall'esecutore richiesta utente e di 
      restituirgli i risultati. 
*/