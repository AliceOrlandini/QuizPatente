package quizpatente;

import java.io.*;
import java.util.*;

public class CacheDati { // (1)
    
    QuizPatenteGUI interfacciaGrafica;
    
    CacheDati(QuizPatenteGUI interfacciaGrafica) {
        
        this.interfacciaGrafica = interfacciaGrafica;
        caricaDatiDaCache(); 
    }
    
    void caricaDatiDaCache() {
        
        try(FileInputStream fin = new FileInputStream("./cache_quiz_patente.bin");
            ObjectInputStream oin = new ObjectInputStream(fin);) {
            
            String nomeUtente           = (String)oin.readObject(); // (2)
            int durataQuiz              = (int)oin.readObject();
            int numeroRisposteSbagliate = (int)oin.readObject();
            int indiceDomandaMostrata   = (int)oin.readObject();
            int numeroSchedaCliccata    = (int)oin.readObject();
            int size                    = (int)oin.readObject();
            
            List<DomandaScheda> listaDomandeScheda = new ArrayList<>(); // (3)
            for(int i = 0; i < size; i++) {
                listaDomandeScheda.add(new DomandaScheda((String)oin.readObject(), (Boolean)oin.readObject(), (String)oin.readObject()));
            }
           
            if(durataQuiz > 0) { // (4)
                interfacciaGrafica.campoNomeUtente.setText(nomeUtente);
                interfacciaGrafica.messaggioErrore.setText("La Scheda " + String.valueOf(numeroSchedaCliccata) + " è stata ricaricata con successo dalla cache");
                interfacciaGrafica.messaggioErrore.setStyle("-fx-text-fill: #2BC223;");
                interfacciaGrafica.messaggioErrore.setVisible(true);
                interfacciaGrafica.ottieniElencoSchede();
                interfacciaGrafica.aggiornaGrafico();
                interfacciaGrafica.numeroSchedaCliccata = numeroSchedaCliccata;
                interfacciaGrafica.meccanismoGioco.riprendiGioco(durataQuiz, numeroRisposteSbagliate, indiceDomandaMostrata, listaDomandeScheda);
            }
  
        } catch(FileNotFoundException fnfe) {
            System.err.println("Errore: cache non trovata");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Errore: impossibile prelevare da cache.");
        }
    }
    
    void salvaDatiInCache() {
        
        try(FileOutputStream fout = new FileOutputStream("./cache_quiz_patente.bin");
            ObjectOutputStream oout = new ObjectOutputStream(fout);) {
            
            oout.writeObject(interfacciaGrafica.campoNomeUtente.getText());
            oout.writeObject(interfacciaGrafica.meccanismoGioco.durataQuiz);
            oout.writeObject(interfacciaGrafica.meccanismoGioco.numeroRisposteSbagliate);
            oout.writeObject(interfacciaGrafica.meccanismoGioco.indiceDomandaMostrata);
            oout.writeObject(interfacciaGrafica.numeroSchedaCliccata);
            
            if(interfacciaGrafica.meccanismoGioco.durataQuiz > 0) { // (5)
                
                oout.writeObject(interfacciaGrafica.meccanismoGioco.listaDomandeScheda.size());
                for(int i = 0; i < interfacciaGrafica.meccanismoGioco.listaDomandeScheda.size(); i++) {
                    
                    oout.writeObject(interfacciaGrafica.meccanismoGioco.listaDomandeScheda.get(i).domanda);
                    oout.writeObject(interfacciaGrafica.meccanismoGioco.listaDomandeScheda.get(i).risposta);
                    oout.writeObject(interfacciaGrafica.meccanismoGioco.listaDomandeScheda.get(i).immagineUrl);
                }
            } else {
                
                int size = 40;
                String domanda = "";
                Boolean risposta = true;
                String immagineUrl = "";
                oout.writeObject(size);
                for(int i = 0; i < size; i++) {
                    oout.writeObject(domanda);
                    oout.writeObject(risposta);
                    oout.writeObject(immagineUrl);
                }
            }    
        } catch(IOException ex) {
            ex.printStackTrace();
        }
    }
}
/*
Note:
(1):  Questa classe gestisce il salvataggio e il caricamento da file bin dei 
      dati relativi al quiz che l'utente sta svolgendo al fine di riprisinare lo
      stato dell'applicazione quando verrà riaperta.
(2):  Vengono letti dalla cache il tempo che all'utente rimaneva per svolgere la
      prova, il numero di risposte che ha sbagliato fino a quel momento, 
      l'indice dell'array di domande a cui si è arrivati, l'id della scheda che 
      era in svolgimento e il numero totale di domande. 
(3):  Viene creata la lista di tipo DomandaScheda e, con il for vengono inseriti
      tutti i dati nella lista.
(4):  Quando durataQuiz è maggiore di zero significa che l'utente stava 
      svolgendo una scheda e quindi bisogna chiamare il metodo riprendiGioco 
      della classe MeccanismoDiGioco per riprendere lo svolgimento della scheda. 
      Altrimenti non si fa niente. 
(5):  Se durataQuiz è maggiore di zero significa che l'utente stava svolgendo
      una scheda e quindi bisogna salvare i dati di quella scheda nella cache.
      Altrimenti vengono salvati dei dati vuoti per non avere problemi quando
      tali dati verranno ricaricati. 
*/